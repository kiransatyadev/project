package com.klef.jfsd.springboot.service;

public class FileInfo {

  public String filename;
  public String path;
  public long filesize;
  public long uploadedbytes;
  
}